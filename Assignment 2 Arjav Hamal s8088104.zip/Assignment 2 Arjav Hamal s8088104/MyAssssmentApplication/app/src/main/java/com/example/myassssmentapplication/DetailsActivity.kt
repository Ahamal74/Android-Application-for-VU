package com.example.myassssmentapplication

// CODE BY ARJAV HAMAL S8088104

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DetailsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)

        // GET PASSED OBJECT FROM INTENT
        val item = intent.getSerializableExtra("selectedItem") as? DashboardItem

        // FIND TEXT VIEWS BY ID
        val tvName = findViewById<TextView>(R.id.tvName)
        val tvArchitect = findViewById<TextView>(R.id.tvArchitect)
        val tvLocation = findViewById<TextView>(R.id.tvLocation)
        val tvStyle = findViewById<TextView>(R.id.tvStyle)
        val tvYear = findViewById<TextView>(R.id.tvYear)
        val tvHeight = findViewById<TextView>(R.id.tvHeight)
        val tvDescription = findViewById<TextView>(R.id.tvDescription)

        // POPULATE VIEWS WITH ITEM DATA
        item?.let {
            tvName.text = it.name
            tvArchitect.text = "ARCHITECT: ${it.architect}"
            tvLocation.text = "LOCATION: ${it.location}"
            tvStyle.text = "STYLE: ${it.style}"
            tvYear.text = "YEAR COMPLETED: ${it.yearCompleted}"
            tvHeight.text = "HEIGHT: ${it.height} M"
            tvDescription.text = "DESCRIPTION:\n${it.description}"
        }

        // BACK BUTTON TO RETURN TO DASHBOARD
        val btnBack = findViewById<Button>(R.id.btnBack)
        btnBack.setOnClickListener {
            finish()  // CLOSES CURRENT ACTIVITY
        }
    }
}
