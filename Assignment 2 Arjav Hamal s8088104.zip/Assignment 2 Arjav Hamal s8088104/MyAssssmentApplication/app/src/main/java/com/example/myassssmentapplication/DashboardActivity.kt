package com.example.myassssmentapplication
// CODE BY ARJAV HAMAL S8088104
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

// DASHBOARD SCREEN
class DashboardActivity : AppCompatActivity() {

    // UI ELEMENTS
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: DashboardAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        // SETUP RECYCLERVIEW
        recyclerView = findViewById(R.id.dashboardRecycler)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // GET KEYPASS FROM LOGIN
        val keypass = intent.getStringExtra("keypass")
        Toast.makeText(this, "Received keypass: $keypass", Toast.LENGTH_LONG).show()

        // LOAD DASHBOARD DATA
        if (keypass != null) {
            fetchDashboardData(keypass)
        } else {
            Toast.makeText(this, "Missing keypass from login", Toast.LENGTH_SHORT).show()
        }
    }

    // FETCH DATA FROM API
    private fun fetchDashboardData(keypass: String) {
        RetrofitClient.instance.getDashboardData(keypass).enqueue(object : Callback<DashboardResponse> {
            override fun onResponse(call: Call<DashboardResponse>, response: Response<DashboardResponse>) {
                if (response.isSuccessful && response.body() != null) {
                    val items = response.body()!!.entities
                    adapter = DashboardAdapter(items)
                    recyclerView.adapter = adapter
                } else {
                    Toast.makeText(this@DashboardActivity, "Failed to load dashboard", Toast.LENGTH_SHORT).show()
                    Log.e("DashboardActivity", "Unsuccessful response: ${response.code()} ${response.message()}")
                }
            }

            override fun onFailure(call: Call<DashboardResponse>, t: Throwable) {
                Toast.makeText(this@DashboardActivity, "Error: ${t.message}", Toast.LENGTH_SHORT).show()
                Log.e("DashboardActivity", "Network error", t)
            }
        })
    }
}
