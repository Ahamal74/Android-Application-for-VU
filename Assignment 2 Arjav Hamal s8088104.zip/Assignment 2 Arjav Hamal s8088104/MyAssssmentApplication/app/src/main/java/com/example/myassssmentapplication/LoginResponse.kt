package com.example.myassssmentapplication

// CODE BY ARJAV HAMAL S8088104

// DATA CLASS FOR LOGIN RESPONSE FROM SERVER
data class LoginResponse(val keypass: String)

