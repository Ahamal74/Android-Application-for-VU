package com.example.myassssmentapplication

// CODE BY ARJAV HAMAL S8088104

// DATA CLASS FOR LOGIN REQUEST PAYLOAD
data class LoginRequest(val username: String, val password: String)
