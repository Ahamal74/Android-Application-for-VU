package com.example.myassssmentapplication

// CODE BY ARJAV HAMAL S8088104

import java.io.Serializable

// DATA CLASS TO HOLD DASHBOARD ITEM DETAILS
data class DashboardItem(
    val name: String,              // NAME OF THE BUILDING
    val architect: String,         // NAME OF THE ARCHITECT
    val location: String,          // LOCATION OF THE BUILDING
    val yearCompleted: Int,        // YEAR IT WAS COMPLETED
    val style: String,             // ARCHITECTURAL STYLE
    val height: Int,               // HEIGHT IN METERS
    val description: String        // FULL DESCRIPTION
) : Serializable                  // MAKES THIS OBJECT TRANSFERABLE BETWEEN ACTIVITIES
