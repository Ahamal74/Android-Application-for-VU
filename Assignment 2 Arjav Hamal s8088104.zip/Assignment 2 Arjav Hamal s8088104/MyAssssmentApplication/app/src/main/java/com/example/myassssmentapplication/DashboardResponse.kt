package com.example.myassssmentapplication

// CODE BY ARJAV HAMAL S8088104

// DATA CLASS FOR DASHBOARD API RESPONSE
data class DashboardResponse (

    val entities: List<DashboardItem>, // LIST OF DASHBOARD ITEMS
    val entityTotal: Int               // TOTAL NUMBER OF ENTITIES RETURNED
)
