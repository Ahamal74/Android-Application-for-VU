package com.example.myassssmentapplication
// CODE BY ARJAV HAMAL S8088104
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

// DEFINES API CALLS
interface ApiService {

    // LOGIN REQUEST
    @POST("sydney/auth")
    fun login(@Body request: LoginRequest): Call<LoginResponse>

    // GET DASHBOARD DATA
    @GET("dashboard/{keypass}")
    fun getDashboardData(
        @Path("keypass") keypass: String
    ): Call<DashboardResponse>
}
