package com.example.myassssmentapplication

// CODE BY ARJAV HAMAL S8088104

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitClient {
    // BASE URL FOR API REQUESTS
    private const val BASE_URL = "https://nit3213api.onrender.com/"

    // SINGLETON INSTANCE OF RETROFIT SERVICE
    val instance: ApiService by lazy {
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL) // SETTING THE BASE URL
            .addConverterFactory(GsonConverterFactory.create()) // ADDING GSON CONVERTER
            .build()

        retrofit.create(ApiService::class.java) // CREATING API SERVICE IMPLEMENTATION
    }
}
