package com.example.myassssmentapplication
// CODE BY ARJAV HAMAL S8088104
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

// ADAPTER TO SHOW DASHBOARD LIST
class DashboardAdapter(private val itemList: List<DashboardItem>) :
    RecyclerView.Adapter<DashboardAdapter.DashboardViewHolder>() {

    // HOLDS UI ELEMENTS FOR EACH ITEM
    inner class DashboardViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title: TextView = itemView.findViewById(R.id.itemTitle)
        val location: TextView = itemView.findViewById(R.id.itemLocation)
        val style: TextView = itemView.findViewById(R.id.itemStyle)
        val year: TextView = itemView.findViewById(R.id.itemYear)
    }

    // CREATES EACH ITEM VIEW
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DashboardViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_dashboard, parent, false)
        return DashboardViewHolder(view)
    }

    // BINDS DATA TO ITEM VIEW
    override fun onBindViewHolder(holder: DashboardViewHolder, position: Int) {
        val item = itemList[position]
        holder.title.text = item.name
        holder.location.text = "Location: ${item.location}"
        holder.style.text = "Style: ${item.style}"
        holder.year.text = "Completed: ${item.yearCompleted}"

        // HANDLE ITEM CLICK -> OPEN DETAILS PAGE
        holder.itemView.setOnClickListener {
            val context = holder.itemView.context
            val intent = Intent(context, DetailsActivity::class.java)
            intent.putExtra("selectedItem", item)
            context.startActivity(intent)
        }
    }

    // RETURNS TOTAL NUMBER OF ITEMS
    override fun getItemCount(): Int = itemList.size
}
